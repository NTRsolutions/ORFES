<footer >
    &copy; 2015 Restaurant Menu Bangladesh | By : <a href="http://www.absoftbd.com/" target="_blank">AB Software Limited</a>
</footer>