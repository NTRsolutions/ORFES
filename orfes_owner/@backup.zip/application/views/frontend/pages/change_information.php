<section class="signup">
    <?php
    if ($this->session->userdata('message')) {
        echo "<div class=\"alert alert-success alert-dismissible col-md-8 col-md-offset-2\" role=\"alert\">
                            <button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
                            " . $this->session->userdata('message') . "
                        </div>";
    }
    $this->session->unset_userdata(array('message'));
    ?>

    <div class="row">
        <div class="col-md-8 col-md-offset-2 sh_form"> 
            <h3> Profile Information</h3>

            <?php echo form_open_multipart(base_url() . 'index.php/information/change_information'); ?>
            <div class="form-group">
                <label for="hotline_number">Hotline Number</label>
                <input type="text" class="form-control" id="contact_number" name="hotline_number" value="<?php echo $info->hotline_number; ?>" >
                <i> <?php echo form_error('hotline_number'); ?></i>   
            </div> 
            <div class="form-group">
                <label for="opening_time">Opening Day & Time - <small class="text-muted">(<?php echo $info->opening_time; ?>)</small></label>
                <div id="opening_day_time">
                    <select name="start_day">
                        <option value="Saturday">Start Day</option>
                        <option value="Saturday">Saturday</option>
                        <option value="Sunday">Sunday</option>
                        <option value="Monday">Monday</option>
                        <option value="Tuesday">Tuesday</option>
                        <option value="Wednesday">Wednesday</option>
                        <option value="Thursday">Thursday</option>
                        <option value="Friday">Friday</option>
                    </select>
                    to
                    <select name="end_day">
                        <option value="Sunday">End Day</option>
                        <option value="Saturday">Saturday</option>
                        <option value="Sunday">Sunday</option>
                        <option value="Monday">Monday</option>
                        <option value="Tuesday">Tuesday</option>
                        <option value="Wednesday">Wednesday</option>
                        <option value="Thursday">Thursday</option>
                        <option value="Friday">Friday</option>
                    </select>
                    <input type="text" name="start_time" placeholder="00:00 AM/PM" maxlength="20" >
                    to
                    <input type="text" name="end_time" placeholder="00:00 AM/PM" maxlength="20" >
                </div> 
                <i> <?php echo form_error('organization'); ?></i>   
            </div>
            <div class="form-group">
                <label for="address"> Flat / Plot / Tower / Floor / Road Name or No.</label>
                <textarea class="form-control" id="address" rows="5" name="address" placeholder="Flat / Plot / Tower / Floor / Road Name or No." ><?php echo $info->address; ?> </textarea>
                <i> <?php echo form_error('address'); ?></i>   
            </div>
            <div class="form-group">
                <label for="postal_code">Postal Code</label>
                <input type="text" class="form-control" id="postal_code" name="postal_code" value="<?php echo $info->postal_code; ?>"  >
                <i> <?php echo form_error('postal_code'); ?></i>   
            </div>
            <div class="form-group">
                <label for="police_station">Police Station</label>
                <input type="text" class="form-control" id="police_station" name="police_station" value="<?php echo $info->police_station; ?>"  >
                <i> <?php echo form_error('police_station'); ?></i>   
            </div>
            <div class="form-group">
                <label for="district_city">District / City</label>  
                <input type="text" class="form-control" id="postal_code" name="district_city" value="<?php echo $info->district_city; ?>"  >
                <i> <?php echo form_error('district_city'); ?></i>   
            </div>
            <div class="form-group">
                <label for="state_division">State / Division</label>  
                <input type="text" class="form-control" id="postal_code" name="state_division" value="<?php echo $info->state_division; ?>"  >
                <i> <?php echo form_error('state_division'); ?></i>   
            </div>

            <div class="form-group">
                <label for="country">Country - <small class="text-muted">(<?php echo $info->country; ?>)</small></label> 
                <?php require 'country.php'; ?>
                <i> <?php echo form_error('country'); ?></i>   
            </div> 
             <input class="btn btn-default col-xs-12 col-md-6 col-sm-6 col-lg-6 col-lg-offset-3 col-md-offset-3 col-sm-offset-3" type="submit" value="Save Information" >
            <?php echo form_close(); ?>
        </div>
    </div>
</section>