<section class="home_content">
    <div class="col-sm-8 col-md-8 col-lg-8 col-md-offset-2 col-lg-offset-2 col-sm-offset-2">
        <div class="article">
            <h4 class="sub_title">About</h4>
            <p class="details" align="justify">
                Get menu card is a restaurant based platform which facilitates its user of getting menu card from restaurants online. This will reduce the necessity of a menu card or even a menu card may become unnecessary. A profile and menu card on getmenucard.com will simply enable customers to check menu card or profile of the desired or nearest restaurant.   
            </p>
        </div> 
    </div>
</section>

