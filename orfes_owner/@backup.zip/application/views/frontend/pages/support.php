<section class="home_content">
    <div class="col-sm-8 col-md-8 col-lg-8 col-md-offset-2 col-lg-offset-2 col-sm-offset-2">
        <div class="article">
            <h4 class="sub_title">For Any Support</h4>
            <br/>
            <p class="details">Please mail us for any support about <a href="http://www.getmenucard.com/">getmenucard.com</a> or Get Menu Card App related.</p>
            <br/>
            <dl>
                <dt>Mail Support: </dt>
                <dd>support@getmenucard.com</dd>
                <dt>Phone Support: </dt>
                <dd>+880 1782 666 111 </dd>
            </dl>
        </div> 
    </div>
</section>

