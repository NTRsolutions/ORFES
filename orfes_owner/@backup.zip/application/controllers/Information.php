<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Information extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->library(array('form_validation',));
        $this->load->helper(array('text', 'url', 'form', 'security'));
        $this->load->model(array('validation_model', 'restaurant_model', 'upload_model', 'information_model', 'date_model', 'mail_model'));
        $data = array();
        if($this->session->userdata('isLogIn') == FALSE){
            redirect(base_url() . 'index.php/pages/index', 'refresh');
        }
    }

    /*
     * @function name - information
     * @parameter - post data
     * @parameter contains profile information form data
     * @return - boolean data
     * @author - Md. Shohrab Hossain
     * @created on - 23/06/2015
     */

    public function change_information() {
        $data['title'] = "Update Profile Information";
        $data['menu_settings'] = "sh_menu";
        #form validation
        if ($this->validation_model->change_information() == TRUE) {
            $opening_time = $this->input->post('start_day') . " to " . $this->input->post('end_day') . " ";
            $opening_time .= $this->security->xss_clean($this->input->post('start_time')) . " - " . $this->security->xss_clean($this->input->post('end_time'));
            $info = array(
                'hotline_number' => $this->security->xss_clean($this->input->post('hotline_number')),
                'opening_time' => $opening_time,
                'address' => $this->security->xss_clean($this->input->post('address')),
                'postal_code' => $this->security->xss_clean($this->input->post('postal_code')),
                'police_station' => $this->security->xss_clean($this->input->post('police_station')),
                'district_city' => $this->security->xss_clean($this->input->post('district_city')),
                'state_division' => $this->security->xss_clean($this->input->post('state_division')),
                'country' => $this->security->xss_clean($this->input->post('country'))
            );
            #information update
            $this->information_model->update($info);
//            if($this->information_model->update($info) == FALSE){
//                $info['restaurant_id'] = $this->session->userdata('restaurant_id'); 
//                $this->information_model->create($info);
//            }
            #ends of information update
            #
            #set session message
            $this->session->set_userdata(array('message' => 'Information save successfully'));
            #ends of set session message
        }
        #ends of validation
        $data['info'] = $this->information_model->read($this->session->userdata('restaurant_id'));
        $data['content'] = $this->load->view('frontend/pages/change_information', $data, TRUE);
        $this->load->view('frontend/main_wrapper', $data);
    }

    /*
     * @function name - logo       
     * @parameter - image
     * @parameter contains change logo / banner form data
     * @return - boolean data
     * @author - Md. Shohrab Hossain
     * @created on - 25/06/2015
     */

    public function change_logo() {
        $data['title'] = "Change Logo / Banner";
        $data['menu_settings'] = "sh_menu";
        #upload logo or banner
        $upload = $this->upload_model->do_upload($upload_path = 'assets/images/banner/', $file_name = 'image',$image_size='500');
        if ($upload) {
            $this->information_model->update(array('image' => $upload));
            $this->session->set_userdata(array('message' => 'Banner upload successfully'));
            #unlink old photo 
            @unlink($this->input->post('old_photo'));
            #ends of unlink
        }
        #ends of logo or banner
        $data['information'] = $this->information_model->read($this->session->userdata('restaurant_id'));
        $data['content'] = $this->load->view('frontend/pages/change_logo', $data, TRUE);
        $this->load->view('frontend/main_wrapper', $data);
    }
	
	public function change_gallery() {
        $data['title'] = "Change Gallery Image";
        $data['menu_settings'] = "sh_menu";
		$data['check'] = 0;
        $upload = $this->upload_model->do_upload($upload_path = 'assets/images/gallery/', $file_name = 'image',$image_size='200');
        if ($upload) {
			$data1['source'] =$upload;
			$data1['user'] =$this->session->userdata('email');
		
		$this->db->insert('tbl_gallery',$data1);
		$this->session->set_userdata(array('message' => 'Gallery Image Uploaded successfully'));
		redirect(base_url() . 'index.php/Information/change_gallery', 'refresh');
        }
        $data['information'] = $this->db->get_where('tbl_gallery',array('user'=>$this->session->userdata('email')))->result_array();
        $data['content'] = $this->load->view('frontend/pages/change_gallery', $data, TRUE);
        $this->load->view('frontend/main_wrapper', $data);
    }
	
	public function update_gallery($para1) {
        $upload = $this->upload_model->do_upload($upload_path = 'assets/images/gallery/', $file_name = 'image',$image_size='200');
        if ($upload) {
			$data1['source'] =$upload;
		
			$this->db->where('image_id',$para1);
			$this->db->update('tbl_gallery',$data1);
            $this->session->set_userdata(array('message' => 'Gallery Image Updated successfully'));
            #unlink old photo 
            @unlink($this->input->post('old_photo'));
            #ends of unlink
        }
		redirect(base_url() . 'index.php/Information/change_gallery', 'refresh');
    }
	
	public function delete_image($para1) {
		@unlink($this->db->get_where('tbl_gallery',array('image_id'=>$para1))->row()->source);
        $this->db->where('image_id',$para1);
		$this->db->delete('tbl_gallery');
		$this->session->set_userdata(array('message' => 'Gallery Image Deleted successfully'));
		redirect(base_url() . 'index.php/Information/change_gallery', 'refresh');
    }
	
	public function add_more() {
		$data['title'] = "Change Gallery Image";
        $data['menu_settings'] = "sh_menu";
        $data['check'] = 1;
        $data['information'] = $this->db->get_where('tbl_gallery',array('user'=>$this->session->userdata('email')))->result_array();
        $data['content'] = $this->load->view('frontend/pages/change_gallery', $data, TRUE);
        $this->load->view('frontend/main_wrapper', $data);
    }
    /*
     * @function name - logo       
     * @parameter - image
     * @parameter contains change logo / banner form data
     * @return - boolean data
     * @author - Md. Shohrab Hossain
     * @created on - 25/06/2015
     */

    public function show() {
        
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function edit($id) {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function destroy($id) {
        //
    }

}

?>