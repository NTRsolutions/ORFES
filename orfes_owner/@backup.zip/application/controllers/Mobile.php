<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Mobile extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper(array('text', 'url', 'form', 'security'));
        $this->load->library(array('form_validation'));
        $this->load->model(array('admin_model', 'report_model', 'validation_model','restaurant_model', 'information_model', 'category_model', 'date_model', 'hash_model', 'capcha_model','mail_model'));
        $data = array();
    }

    /*
     * @function name - index
     * @parameter - email and password
     * @parameter contains signin form data
     * @return - boolean data
     * @author - Md. Shohrab Hossain
     * @created on - 19/05/2015
     */

    public function index() { 
        
        $data['title'] = "Home";
        $data['menu_home'] = "sh_menu";
        $data['content'] = $this->load->view('frontend/mobile/home', '', TRUE);
        $this->load->view('frontend/main_wrapper_mobile', $data);
	}
	
	public function search_home() {
        redirect(base_url() . 'index.php/mobile/profile/'.$this->input->post('search'), 'refresh');
    }
	
	 public function profile($username) {
        $data['title'] = "Restaurant Profile";
        $data['menu_settings'] = "sh_menu";
        $data['restaurant'] = $this->restaurant_model->read_by_username($username);
        if ($data['restaurant'] == '') {
            show_404();
        } else {
            $data['category'] = $this->category_model->read($data['restaurant']->restaurant_id);
            $data['information'] = $this->information_model->read($data['restaurant']->restaurant_id);
            $data['content'] = $this->load->view('frontend/mobile/profile', $data, TRUE);
            $this->load->view('frontend/main_wrapper_mobile', $data);
        }
    }
	 public function jquery_search_mobile($search_mobile = null) {
        $search = urldecode($search_mobile);
        echo "<div class=\"media sh_search\"><i class=\"fa fa-keyboard-o text-success\"></i> $search</div>";
        $this->db->select("*");
        $this->db->from('tbl_restaurant');
        $this->db->join('tbl_information', 'tbl_restaurant.restaurant_id = tbl_information.restaurant_id');
        $this->db->where('tbl_restaurant.status', 1);
        $this->db->group_start();
        $this->db->like('tbl_restaurant.username', $search_mobile);
        $this->db->or_like('tbl_restaurant.name', $search_mobile);
        $this->db->or_like('hotline_number', $search_mobile);
        $this->db->or_like('address', $search_mobile);
        $this->db->or_like('postal_code', $search_mobile);
        $this->db->or_like('police_station', $search_mobile);
        $this->db->or_like('district_city', $search_mobile);
        $this->db->or_like('police_station', $search_mobile);
        $this->db->or_like('country', $search_mobile);
        $this->db->group_end();
        $this->db->limit(100);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            echo "<div class='media sh_search' style='color:green'>Total <strong>$query->num_rows</strong> record found</div>";
            $sl = 1;

            echo "<div class=\"media sh_search\">
                    <div class=\"media-left\"><strong>#</strong></div>
                    <div class=\"media-body media-first\"><strong>Restaurant Name</strong></div>
                    <div class=\"media-body\"><strong>Location</strong></div>
                    <div class=\"media-right\"><strong>Action</strong></div>
                 </div>";

            foreach ($query->result() as $value) {
                echo "<div class=\"media sh_search\">";
                echo "<div class=\"media-left\">" . $sl++ . "</div>";
                echo "<div class=\"media-body media-first\">";
                echo "$value->name <br/>";
                echo "<strong>Hotline Number </strong>- $value->hotline_number <br/>";
                echo "</div>";
                echo "<div class=\"media-body\">";
                echo "$value->address, $value->postal_code, $value->police_station, ";
                echo "$value->district_city, $value->state_division, $value->country. ";
                echo "</div>";
                echo "<div class=\"media-right\" style='padding:5px'>";
                echo "<a class=\"btn btn-default\" href=" . base_url().'/index.php/mobile/profile/' . $value->username . ">Details</a>";
                echo "</div>";
                echo "</div>";
            }
        } else {
            echo "<div class=\"media sh_search\" style=\"color:red\">No record found</div>";
        }
    }
	
	public function search_advanced() {
        $data['title'] = "Advanced Search";
        $data['menu_adv_search'] = "sh_menu";
        $data['content'] = $this->load->view('frontend/mobile/search_advanced', '', TRUE);
        $this->load->view('frontend/main_wrapper_mobile', $data);
    }
	public function search() {
        $data['title'] = "Advanced Search";
        $data['menu_adv_search'] = "sh_menu";
        $search = $this->input->post('search');
        $this->load->model('restaurant_model');
        $data['search_item'] = $this->restaurant_model->search($this->input->post('search'));
        $data['content'] = $this->load->view('frontend/mobile/search', $data, TRUE);
        $this->load->view('frontend/main_wrapper_mobile', $data);
    }
	
	public function search_nearest_restaurant() {
        $data['title'] = "Search Nearest Restaurant";
        $data['menu_search'] = "sh_menu";
        $data['content'] = $this->load->view('frontend/mobile/search_nearest_restaurant', '', TRUE);
        $this->load->view('frontend/main_wrapper_mobile', $data);
    }
	
	public function search_nearest_restaurant_result() {
        $this->load->model(array('restaurant_model'));
        $data['title'] = "Search Nearest Restaurant";
        $data['menu_search'] = "sh_menu";
        $search = array(
            'country' => $this->security->xss_clean($this->input->post('country')),
            'state_division' => $this->security->xss_clean($this->input->post('state_division')),
            'district_city' => $this->security->xss_clean($this->input->post('district_city')),
            'police_station' => $this->security->xss_clean($this->input->post('police_station')),
            'postal_code' => $this->security->xss_clean($this->input->post('postal_code'))
        );
        $data['restaurant'] = $this->restaurant_model->search_nearest_restaurant($search);
        $data['content'] = $this->load->view('frontend/mobile/search_nearest_restaurant_result', $data, TRUE);
        $this->load->view('frontend/main_wrapper_mobile', $data);
    }
    
}
