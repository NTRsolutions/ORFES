<section class="search">
    <div class="col-sm-8 col-md-8 col-lg-8 col-md-offset-2 col-lg-offset-2 col-sm-offset-2">
        <h3 class="sh_title text-center">Get Restaurant Menu Card</h3>
        <form action="<?php echo base_url(); ?>pages/search_home" method="post">
            <div class="form-group">
                <label for="search" class="sr-only">Search</label>
                <input type="search" name="search" class="form-control" placeholder="Enter Restaurant Username" required>
            </div>
            <div class="form-group">
                <input class="btn btn-default col-xs-12 col-md-6 col-sm-6 col-lg-6 col-lg-offset-3 col-md-offset-3 col-sm-offset-3" type="submit" value="Get" >
            </div>
        </form>
    </div>
</section>

<section class="home_content">
    <div class="col-sm-8 col-md-8 col-lg-8 col-md-offset-2 col-lg-offset-2 col-sm-offset-2">
        <div class="article">
            <h4 class="sub_title">Get Restaurant Menu Card</h4>
            <p class="details">
                Consumers want to see the new technology they use integrated into their dining ... 
                Hand them a restaurant iPad they can self-checkout on where their card doesn't leave ...
                Watch for fast-food restaurants to change menus more often, .... 
                Sure, you've heard the hype about content marketing, read articles on 
                Watch for fast-food restaurants to change menus more often, .... 
                Sure, you've heard the hype about content marketing, read articles on  
                Watch for fast-food restaurants to change menus more often, ....  
            </p>
        </div>
        <div class="article">
            <h4 class="sub_title">Search Nearest Restaurant</h4>
            <p class="details">
                Consumers want to see the new technology they use integrated into their dining ... 
                Hand them a restaurant iPad they can self-checkout on where their card doesn't leave ...
                Watch for fast-food restaurants to change menus more often, .... 
                Sure, you've heard the hype about content marketing, read articles on 
                Watch for fast-food restaurants to change menus more often, .... 
                Sure, you've heard the hype about content marketing, read articles on  
                Watch for fast-food restaurants to change menus more often, ....  
            </p>
        </div>
    </div>
</section>

