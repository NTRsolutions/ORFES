<blockquote>
  <p>Your Account activation successfully. Please login now</p>
  <footer>Thanks </footer>
</blockquote>