<section class="profile">
    <div class="">
        <div class="restaurant_info">
            <?php if (!empty($information->image)) { ?>
                <img class="banner img-responsive" src="<?php echo base_url() . $information->image; ?>" alt="banner"/>
            <?php } else { ?>
                <img class="banner img-responsive" style="width:100%" src="<?php echo base_url(); ?>assets/images/icons/banner.jpg" alt="Logo / Banner"/>
            <?php } ?>
            <h2><?php echo $restaurant->name; ?> </h2>

            <dl class="dl-horizontal">
                <dt>Restaurant Username</dt><dd><?php echo $restaurant->username; ?><dd>
                <dt> Email</dt><dd><?php echo $restaurant->email; ?><dd>
                <dt> Opening Day</dt><dd><?php if (isset($information->opening_time)) echo $information->opening_time; ?><dd>
                <dt> Hotline</dt><dd><?php if (isset($information->hotline_number)) echo $information->hotline_number; ?><dd>
                <dt> Address</dt>
                <dd>
                    <?php
                    if (isset($information->address) && ($information->address != ''))
                        echo "$information->address, ";
                    if (isset($information->postal_code) && ($information->postal_code != ''))
                        echo "$information->postal_code, ";
                    if (isset($information->police_station) && ($information->police_station != ''))
                        echo "$information->police_station, ";
                    if (isset($information->district_city) && ($information->district_city != ''))
                        echo "$information->district_city, ";
                    if (isset($information->state_division) && ($information->state_division != ''))
                        echo "$information->state_division, ";
                    if (isset($information->country) && ($information->country != ''))
                        echo "$information->country  ";
                    ?>
                <dd> 
            </dl>


        </div>
    </div>
    <div class="menu_card_info">
        <!-- Nav tabs -->
        <h3 class="text-center main_title"><?php echo $restaurant->name; ?> Menu Card &nbsp;&nbsp; </h3>
        <!-- Tab panes -->
        <div class="tab-content tab-pane"> 
            <?php
            foreach ($category as $cate) {
                ?>
                <div class="category_item">
                    <h4 class="sh_title text-center"><?php echo $cate->category_name; ?></h4>
                    <?php
                    $this->load->database();
                    $query = $this->db->select('*')
                            ->from('tbl_item')
                            ->where('restaurant_id', $cate->restaurant_id)
                            ->where('category', $cate->category_name)
                            ->where('status', 1)
                            ->get();
                    foreach ($query->result() as $value) {
                        ?>
                        <div class="media" >
                            <div class="media-left media-middle">
                                <a href="#">
                                    <img class="media-object" src="<?php echo base_url() . $value->image; ?>" alt="Caption" width="64" height="64">
                                </a>
                            </div>
                            <div class="media-body">
                                <h4 class="media-heading"><?php echo $value->item_name; ?> <?php
                                    if ($value->item_type == "Add A Special Offer") {
                                        echo '<i class="fa fa-star text-danger"></i>';
                                    }
                                    ?></h4>
                                <?php echo $value->about; ?>
                                <br/>
                                <span class="text-success">Regular Price: <strong><?php echo $value->regular_price; ?></strong></span>&nbsp;&nbsp;
                                <?php if ($value->item_type == "Add A Special Offer") { ?>
                                    <span class="text-danger">Special Price: <strong><?php echo $value->special_price; ?></strong></span>
                                <?php } ?>
                            </div>
                        </div>
                    <?php } ?>
                </div>
            <?php } ?>
        </div>                      
    </div>
</section>   
