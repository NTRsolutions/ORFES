<section class="home_content">
    <div class="col-sm-8 col-md-8 col-lg-8 col-md-offset-2 col-lg-offset-2 col-sm-offset-2">
        <div class="article">
            <h4 class="sub_title">For Any Support</h4>
            <br/>
            <p class="details">Please knock us for any support GetMenuCard.com related.</p>
            <br/>
            <dl>
                <dt>Mail Support : </dt>
                <dd>support@getmenucard.com</dd>
                <dt>Phone Support : </dt>
                <dd>+880 1782 666 111 </dd>
                <dt>Skype Support : </dt>
                <dd>getmenucard</dd>
            </dl>
        </div> 
    </div>
</section>

