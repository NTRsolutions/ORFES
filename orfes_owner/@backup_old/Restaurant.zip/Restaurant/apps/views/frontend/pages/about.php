<section class="home_content">
    <div class="col-sm-8 col-md-8 col-lg-8 col-md-offset-2 col-lg-offset-2 col-sm-offset-2">
        <div class="article">
            <h4 class="sub_title">About</h4>
            <p class="details">
                Consumers want to see the new technology they use integrated into their dining ... 
                Hand them a restaurant iPad they can self-checkout on where their card doesn't leave ...
                Watch for fast-food restaurants to change menus more often, .... 
                Sure, you've heard the hype about content marketing, read articles on 
                Watch for fast-food restaurants to change menus more often, .... 
                Sure, you've heard the hype about content marketing, read articles on  
                Watch for fast-food restaurants to change menus more often, ....  
            </p>
        </div> 
    </div>
</section>

