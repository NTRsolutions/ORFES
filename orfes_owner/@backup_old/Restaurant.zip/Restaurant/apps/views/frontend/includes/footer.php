<div class="col-md-8 col-sm-7 footer_menu">
    <ul class="list-inline">
        <li><a href="<?php echo base_url() ?>pages/about">About</a></li> 
        <li><a href="<?php echo base_url() ?>pages/support">For Support</a></li>  
    </ul>   
</div>

<div class="col-md-4 col-sm-5 text-right social">
    <ul class="list-inline">
        <li class="sh_round sh_transition"><a href="https://www.facebook.com/pages/getmenucardcom/415079848656795" title="Get Menu Card on Facebook" target="_blank"><i class="fa fa-facebook"></i></a>
        </li>
        <li class="sh_round sh_transition"><a href="https://twitter.com/getmenucard" title="Get Menu Card on Twitter" target="_blank"><i class="fa fa-twitter"></i></a>
        </li>
        <li class="sh_round sh_transition"><a href="https://plus.google.com/103815737982702536020/about" title="Get Menu Card on Google+" target="_blank"><i class="fa fa-google-plus"></i></a>
        </li> 
    </ul>
</div>
