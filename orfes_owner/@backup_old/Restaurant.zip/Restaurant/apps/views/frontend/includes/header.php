<div class="row">
    <div class="col-md-4">
        <a class="logo"  href="<?php echo base_url(); ?>">
            <img src="<?php echo base_url(); ?>assets/images/icons/logo.png" alt="Logo"/>
        </a>
    </div>
    <div class="col-md-8 col-sm-8 col-xs-12">

        <div class="mobile_apps  pull-right">   
            <ul class="list-inline">
                <li>
                    <a href="<?php echo base_url(); ?>">
                        <img src="<?php echo base_url(); ?>assets/images/icons/app_android.png" alt="Logo"/>
                    </a> 
                </li>
                <li>
                    <a href="<?php echo base_url(); ?>">
                        <img src="<?php echo base_url(); ?>assets/images/icons/app_apple.png" alt="Logo"/>
                    </a> 
                </li>
                <li>
                    <a href="<?php echo base_url(); ?>">
                        <img src="<?php echo base_url(); ?>assets/images/icons/app_win.png" alt="Logo"/>
                    </a> 
                </li>  
            </ul>   
        </div>
    </div> 
</div>