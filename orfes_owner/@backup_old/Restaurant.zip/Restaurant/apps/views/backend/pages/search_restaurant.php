<div class="row">
    <div class="col-md-12">
        <h1 class="page-head-line">Search Restaurant</h1>
    </div>
</div>
<div class="row"> 
    <div class="search_restaurant">
        <section class="search_advanced">
            <div class="col-sm-8 col-md-12"> 
                <div class="form-group">
                    <label for="search" class="sr-only">Search</label>
                    <input type="search" name="search" class="form-control" id="search" placeholder="Type Anything" required>
                </div>
            </div>
        </section>

        <section id="finalResult"></section>
    </div>