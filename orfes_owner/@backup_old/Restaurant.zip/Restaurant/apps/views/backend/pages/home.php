<div class="row">
    <div class="col-md-12">
        <h1 class="page-head-line">Dashboard</h1>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="alert alert-warning">
            Hey,
            <br />
            Hope You Like this template, Please look in to <strong><a  href="http://www.absoftbd.com/" target="_blank">AbSoftBD.Com</a></strong> always for these type of free templates and snippets.
            Which will remain free forever. You can tell your friends about us if you like our work/templates/snippets.
            <br /><br />
            Thanks & Regards
            <br />
            <strong><a href="http://www.absoftbd.com/" target="_blank">AB Software Limited</a></strong> 
        </div>
    </div>
</div>
