<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Category_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    /*
     * @function name - create 
     * @author - Md. Shohrab Hossain
     * @created on - 25/06/2015
     */

    public function create($data) {
        return $this->db->insert('tbl_category', $data);
    }

    /*
     * @function name - read 
     * @author - Md. Shohrab Hossain
     * @created on - 25/06/2015
     */

    public function read($restaurant_id) {
        $query = $this->db->select('*')
                ->from('tbl_category')
                ->where('restaurant_id', $restaurant_id)
                ->order_by('category_name')
                ->get()
                ->result();
        return $query;
    }

    /*
     * @function name - update 
     * @author - Md. Shohrab Hossain
     * @created on - 25/06/2015
     */

    public function update($data) {
        return $this->db->insert('tbl_category', $data);
    }

    /*
     * @function name - delete 
     * @author - Md. Shohrab Hossain
     * @created on - 25/06/2015
     */

    public function delete($id) { 
        $this->db->where("sha1(category_id)",$id);
        $this->db->delete('tbl_category');
    }

}

?>