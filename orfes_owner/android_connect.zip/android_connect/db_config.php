<?php

/*
 * All database connection variables
 */

define('DB_USER', "getmenuc_anik"); // db user
define('DB_PASSWORD', "BhaD85Wb-hA0"); // db password (mention your db password here)
define('DB_DATABASE', "getmenuc_db_restaurant"); // database name
define('DB_SERVER', "localhost"); // db server
?>